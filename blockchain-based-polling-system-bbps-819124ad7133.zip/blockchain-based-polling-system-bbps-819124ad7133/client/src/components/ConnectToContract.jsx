import getWeb3 from "./getWeb3";
//import Polling from "/home/kali/milestone 3/smart_contract/build/contracts/Polling.json";
import React, { Component } from "react";
import { Link } from "react-router-dom";

export default class ConnectToContract extends Component {
  constructor(props) {
    super(props);
    this.state = {
      PollingInstance: undefined,
      account: null,
      web3: null,
      isAdmin: false,
      elStarted: false,
      elEnded: false,
      elDetails: {},
    };
  }

    componentDidMount = async () => {
        if (!window.location.hash) {
          window.location = window.location + "#loaded";
          window.location.reload();
        }
        try {
          // Get network provider and web3 instance.
          const web3 = await getWeb3();
    
          // Use web3 to get the user's accounts.
          const accounts = await web3.eth.getAccounts();
    
          // Get the contract instance.
          const networkId = await web3.eth.net.getId();
          //const deployedNetwork = Polling.networks[networkId];
          //const instance = new web3.eth.Contract(
            //Polling.abi,
            //deployedNetwork && deployedNetwork.address
          //);
    
          // Set web3, accounts, and contract to the state, and then proceed with an
          // example of interacting with the contract's methods.
          this.setState({
            web3: web3,
            //PollingInstance: instance,
            account: accounts[0],
          });

          //Create a poll
          //this.state.PollingInstance.methods.createPoll(_title, _description, _category, _options).call();

        } catch (error) {
            // Catch any errors for any of the above operations.
            alert(
              `Failed to load web3, accounts, or contract. Check console for details.`
            );
            console.error(error);
        }
    }
}