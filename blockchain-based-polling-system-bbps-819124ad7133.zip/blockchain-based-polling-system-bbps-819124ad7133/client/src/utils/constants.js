import abi from './PollContract.json';

export const contractABI = abi.abi;
export const contractAddress = '0x5157C5404745B26cfef518fAAF2168e2EAEE4795';